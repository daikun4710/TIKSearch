from TikTokApi import TikTokApi
import asyncio
import os
import spacy
#import re
nlp = spacy.load("ja_core_news_sm")
#def remove_emojis(text):
 #   emoji_pattern = re.compile("["
    #                        u"\U0001F600-\U0001F64F"  # スマイル絵文字
    #                        u"\U0001F300-\U0001F5FF"  # グラフィック絵文字
    #                        u"\U0001F680-\U0001F6FF"  # 乗り物絵文字
    #                        u"\U0001F700-\U0001F77F"  # アルファベット記号
    #                        u"\U0001F780-\U0001F7FF"  # 技術記号
    #                        u"\U0001F800-\U0001F8FF"  # 付点符号
    #                        u"\U0001F900-\U0001F9FF"  # エモーション
    #                        u"\U0001FA00-\U0001FA6F"  # スポーツ
    #                        u"\U0001FA70-\U0001FAFF"  # 食べ物
    #                        u"\U0001F004-\U0001F0CF"  # デッキ
    #                        u"\U0001F170-\U0001F251"  # 記号
    #                        "]+", flags=re.UNICODE)
    # return emoji_pattern.sub(r'', text)

ms_token = os.environ.get(
    "ms_token", None
)


async def user_example():
    async with TikTokApi() as api:
        await api.create_sessions(ms_tokens=[ms_token], num_sessions=1, sleep_after=3)
        user = api.user("_high_genkides")
        user_data = await user.info()
        # print(user_data)

        async for video in user.videos(count=5):
            #print(video)
            #print(video.as_dict)





             #avatar_larger = video.as_dict['author']['avatarLarger']
             #avatar_larger = video.as_dict['author']['challenges']['contents']['desc']['avatarThumb']
             #print(avatar_larger)
             video_description = video.as_dict['desc']

             #print("動画の概要欄:", video_description)
             #clean_text = remove_emojis(video_description)
             doc = nlp(video_description)
             #cta = 1
             for ent in doc.ents:
                print(f"テキスト: {ent.text}, カテゴリ: {ent.label_}")
                #cta += 1
            #  ct = 0
            #  if ct == 2:
            #      break
            #  else:
            #      ct += 1
if __name__ == "__main__":
   asyncio.run(user_example())
